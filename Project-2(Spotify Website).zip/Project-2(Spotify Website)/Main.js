console.log("Welcome To MyMusic Website");

let songIndex=0;
let audioElemenet= new Audio('Song1.mp3');
let masterplay=document.getElementById('MasterPlay');
let myProgressBar=document.getElementById('myProgressBar');
let gif=document.getElementById('gif');
let songcontext=document.getElementById('SongContext');
let songitems=Array.from(document.getElementsByClassName('songs'));


//List is made here as we have to use GoToNextSong and GoToPreviousSong button
let songs =[
    {songName:"Lehra Do" ,filePath:"Song1.mp3" ,coverPath:"Song-1Icon.webp"},
    {songName:"Jai Jai Shiv Shankar" ,filePath:"Song2.mp3" ,coverPath:"Song-2Icon.jpg"},
    {songName:"Jaako Rakhe Saiyaan" ,filePath:"Song3.mp3" ,coverPath:"Song-34Icon.jpeg"},
    {songName:"Saki Saki" ,filePath:"Song4.mp3" ,coverPath:"Song-34Icon.jpeg"},
    {songName:"Namo Namo" ,filePath:"Song5.mp3" ,coverPath:"Song-5Icon.jpeg"},
    {songName:"Falak Tak" ,filePath:"Song6.mp3" ,coverPath:"Song-6Icon.jpeg"},
    {songName:"Dewana kar raha hai" ,filePath:"Song7.mp3" ,coverPath:"Song-7Icon.jpeg"}
]

//updating the img +name in html
songitems.forEach((element,i) => {   //[0] is used as getelementbyclassname or getelementbytagname will return array while we want to access the 1 element.
    element.getElementsByTagName('img')[0].src =songs[i].coverPath;
    element.getElementsByClassName('songname')[0].innerHTML=songs[i].songName;
});




//Handle play/pause click
masterplay.addEventListener('click',function(){    //It can be written in 3 ways.(other present on      line:-53)
   if(audioElemenet.paused || audioElemenet.currentTime==0){
        audioElemenet.play();
        masterplay.classList.remove('fa-circle-play');
        masterplay.classList.add('fa-circle-pause');
        gif.style.opacity=1;
        songcontext.style.opacity=1;
    }
    else{
        audioElemenet.pause();
        masterplay.classList.remove('fa-circle-pause');
        masterplay.classList.add('fa-circle-play');
        gif.style.opacity=0;
        songcontext.style.opacity=0;
    }
})

//handle range input bar
//.addEventListener :- It is used to handle the events.

audioElemenet.addEventListener('timeupdate',()=>{   //timeupdate is the event when there is change in time 
    // console.log('timeupdate');   //It is written here to show that after each 1 sec, this function will run
    let progress=parseInt((audioElemenet.currentTime/audioElemenet.duration)*100);
    myProgressBar.value =progress;
})

myProgressBar.addEventListener('change',()=>{
    let progress=myProgressBar.value;
    audioElemenet.currentTime=(progress*audioElemenet.duration)/100;
})



//Now to make song list working

function allpause(){
    Array.from(document.getElementsByClassName('songitemlay')).forEach(element =>{
        element.classList.remove('fa-circle-pause');
        element.classList.add('fa-circle-play');
    })
}

Array.from(document.getElementsByClassName('songitemlay')).forEach(element =>{
    element.addEventListener('click',(e)=>{
        allpause();
        songIndex=parseInt(e.target.id);
        e.target.classList.remove('fa-circle-play');
        e.target.classList.add('fa-circle-pause');

        audioElemenet.src=`Song${songIndex+1}.mp3`;
        audioElemenet.currentTime=0;
        audioElemenet.play();
        masterplay.classList.remove('fa-circle-play');
        masterplay.classList.add('fa-circle-pause');
        gif.style.opacity=1;
        songcontext.style.opacity=1;
        songcontext.innerHTML=songs[songIndex].songName;
    })
})


//Now to make work of go back and go next button.

document.getElementById('firsticon').addEventListener('click',()=>{
    allpause();
    if(songIndex==0){
        songIndex=6;
    }
    else{
        songIndex-=1;
    }
    audioElemenet.src=`Song${songIndex+1}.mp3`;
    audioElemenet.currentTime=0;
    audioElemenet.play();
    masterplay.classList.remove('fa-circle-play');
    masterplay.classList.add('fa-circle-pause');
    gif.style.opacity=1;
    songcontext.style.opacity=1;
    songcontext.innerHTML=songs[songIndex].songName;

    //Now i want to change play/pause button of song in list.
})
document.getElementById('nextsong').addEventListener('click',()=>{
    allpause();
    if(songIndex==6){
        songIndex=0;
    }
    else{
        songIndex+=1;
    }
    audioElemenet.src=`Song${songIndex+1}.mp3`;
    audioElemenet.currentTime=0;
    audioElemenet.play();
    masterplay.classList.remove('fa-circle-play');
    masterplay.classList.add('fa-circle-pause');
    gif.style.opacity=1;
    songcontext.style.opacity=1;
    songcontext.innerHTML=songs[songIndex].songName;

    //Now i want to change play/pause button of song in list.
})


//Now if the song get finished it get directed to next song

audioElemenet.addEventListener('timeupdate',()=>{
    if(audioElemenet.currentTime==audioElemenet.duration){
        if(songIndex==6){
            songIndex=0;
        }
        else{
            songIndex+=1;
        }
        allpause();
        audioElemenet.src=`Song${songIndex+1}.mp3`;
        audioElemenet.currentTime=0;
        audioElemenet.play();
        masterplay.classList.remove('fa-circle-play');
        masterplay.classList.add('fa-circle-pause');
        gif.style.opacity=1;
        songcontext.style.opacity=1;
        songcontext.innerHTML=songs[songIndex].songName;
    }
})